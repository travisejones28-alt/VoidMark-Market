local _,M=...
-- Local banker analytics. Auction snapshots are observations, not executed trades.
-- All state is scoped to the current realm/faction economy by Database.lua.
function M:RecordBankerScan(summary)
  if not self.db or not self.db.banker then return end
  local banker=self.db.banker
  local prior=banker.latest or {}
  local found,news={},{}
  local top=self.db.opportunities or {}
  for i=1,math.min(#top,200) do
    local o=top[i]
    if o and o.marketKey and o.pass then
      local key=tostring(o.marketKey)
      found[key]={score=o.score,ask=o.floor}
      if not (prior.items and prior.items[key]) then
        news[#news+1]={key=key,score=o.score,name=o.name or ('Item '..tostring(o.itemID))}
      end
    end
  end
  banker.latest={at=time(),scanID=summary.marketScanID or 0,items=found}
  banker.new=news -- capped by the 200-opportunity ranking
  banker.previousAt=prior.at
  -- Compare only independent completed scans. Cached analyses do not call this path.
  banker.movements={};banker.watchPrices=banker.watchPrices or {}
  for key,watch in pairs(self.db.watchlist or {}) do
    local m=self.db.market[key];local old=banker.watchPrices[key]
    local price=m and m.latest and m.latest.floor
    if type(watch)=='table' and m and not m.cacheUntrusted and not m.analysisIncomplete and self:MarketFresh(m) and self:Finite(price,1,1e12) then
      if old and self:Finite(old.price,1,1e12) and old.scanID~=summary.marketScanID then
        local change=price/old.price-1
        local crossed=watch.target and old.price>watch.target and price<=watch.target
        if math.abs(change)>=0.10 or crossed then
          banker.movements[#banker.movements+1]={name=m.name or tostring(key),change=change,price=price,target=crossed}
        end
      end
      banker.watchPrices[key]={price=price,scanID=summary.marketScanID}
    end
  end
  for key in pairs(banker.watchPrices) do if not self.db.watchlist[key] then banker.watchPrices[key]=nil end end
  table.sort(banker.movements,function(a,b) return math.abs(a.change)>math.abs(b.change) end)
  self:RefreshUI()
end

function M:SetWatch(marketKey,target)
  if self.persistenceBlocked then return false,'Database read-only' end
  local key,id=self:ParseKey(marketKey)
  if not key then return false,'Select an item or enter a valid item ID' end
  local market=self.db.market[key]
  local book=self:ListBook(self.activeList)
  if not book then return false,'List unavailable' end
  if target~=nil and (not self:Finite(target,1,1e12) or target%1~=0) then return false,'Target must be positive copper' end
  local count=0
  for _ in pairs(book) do count=count+1 end
  if not book[key] and count>=200 then return false,'200 watch entries maximum' end
  book[key]={at=time(),target=target,itemID=id,name=market and market.name or (GetItemInfo and GetItemInfo(id)) or ('Item '..id)}
  self:PublishWatch(self.activeList,key,book[key])
  self:RefreshUI()
  return true
end
function M:RemoveWatch(marketKey)
  if self.persistenceBlocked then return false end
  local book=self:ListBook(self.activeList); if not book or not book[marketKey] then return false end
  book[marketKey]=nil;self:PublishWatch(self.activeList,marketKey,nil); self:RefreshUI(); return true
end
function M:GetWatchRows()
  local out={}
  for key,entry in pairs(self:ListBook(self.activeList) or {}) do
    if type(entry)=='table' then
      local m=self.db.market[key]
      local p=self:PriceObservation(key)
      local fresh=p and not p.unverified and time()-p.at<=self.db.settings.maxDataAge
      local floor=p and p.floor or 0
      local status=not p and 'MISSING' or not fresh and 'STALE'
        or (entry.target and floor>0 and floor<=entry.target) and 'TARGET' or 'WATCH'
      out[#out+1]={marketKey=key,itemID=m and m.itemID or entry.itemID,name=m and m.name or entry.name or tostring(key),
        floor=floor,fair=m and m.fairValue or 0,target=entry.target,confidence=m and m.confidence or 'Unknown',
        status=status,watchedAt=entry.at or 0,fresh=fresh}
    end
  end
  table.sort(out,function(a,b)
    if (a.status=='TARGET')~=(b.status=='TARGET') then return a.status=='TARGET' end
    return tostring(a.name)<tostring(b.name)
  end)
  return out
end
function M:GetPortfolioRows()
  local rows={}
  local totals={cost=0,marketValue=0,estimatedNet=0,unrealized=0,unvaluedCost=0,positions=0,quantity=0}
  local cut=self.db.settings.ahCut or 0.05
  local allowance=self.db.settings.depositReserve or 0
  for _,lot in pairs(self.db.inventory or {}) do
    if type(lot)=='table' and lot.character==self.characterID then
      local qty,cost=tonumber(lot.quantity) or 0,tonumber(lot.cost) or 0
      if self:Finite(qty,0,1e9) and self:Finite(cost,0,1e14) and qty>0 then
        local m=self.db.market[lot.marketKey]
        local fresh=self:CanEstimateResale(m)
        local gross=fresh and math.floor(qty*m.fairValue) or nil
        local net=gross and math.max(0,gross-math.ceil(gross*cut)-math.ceil(qty*allowance)) or nil
        local unrealized=net and net-cost or nil
        totals.positions=totals.positions+1; totals.quantity=totals.quantity+qty
        totals.cost=totals.cost+cost
        if net then
          totals.marketValue=totals.marketValue+gross
          totals.estimatedNet=totals.estimatedNet+net
          totals.unrealized=totals.unrealized+unrealized
        else totals.unvaluedCost=totals.unvaluedCost+cost end
        rows[#rows+1]={marketKey=lot.marketKey,name=m and m.name or ('Item '..tostring(lot.marketKey)),
          quantity=qty,cost=cost,basis=cost/qty,marketValue=gross,estimatedNet=net,
          unrealized=unrealized,roi=cost>0 and unrealized and unrealized/cost or nil,
          status=fresh and 'ESTIMATE' or 'UNPRICED',firstSeen=lot.firstSeen,
          ageDays=lot.firstSeen and math.max(0,math.floor((time()-lot.firstSeen)/86400)) or nil}
      end
    end
  end
  table.sort(rows,function(a,b)return a.cost>b.cost end)
  return rows,totals
end
function M:GetBankerSummary()
  local ledger=self:LedgerTotals()
  local rows,portfolio=self:GetPortfolioRows()
  local reserve=self.db.settings.minGoldReserve or 0
  local money=GetMoney and GetMoney() or 0
  local available=math.max(0,money-ledger.reserved-reserve)
  return {gold=money,reserve=reserve,available=available,pending=ledger.reserved,
    realized=ledger.realized,revenue=ledger.revenue,fees=ledger.fees,
    portfolio=portfolio,portfolioRows=rows,scanner=self.db.banker,
    latestScan=self.db.latestScan}
end

-- Nonblocking search across the existing indexed snapshot; capped to avoid 20k-row UI allocations.
function M:BuildBrowseRows(query)
  self:CancelJob('browse')
  local token=(self.browseToken or 0)+1;self.browseToken=token
  local keys=self.marketIndex or {};local i=1;local out={}
  local needle=tostring(query or ''):lower()
  self.browseRows={};local sharedCursor
  self:AddJob('browse',function(start)
    for j=1,80 do
      if #out>=300 then return true end
      if i>#keys then
       local key,s=next(self.db.sharedPrices,sharedCursor);sharedCursor=key;if not key then return true end
       if type(s)=='table' and not self.db.market[key] then
        local name=(GetItemInfo and GetItemInfo(s.id)) or ('Item '..tostring(s.id))
        if needle=='' or tostring(s.id)==needle or name:lower():find(needle,1,true) then
         local fresh=self:Finite(s.at,time()-(self.db.settings.maxDataAge or 7200),time()+60)
         out[#out+1]={marketKey=key,itemID=s.id,name=name,floor=s.floor or 0,fair=s.fair or 0,
          modelReady=fresh and s.reliable,confidence='Shared',status=fresh and 'SHARED*' or 'SHARED OLD'}
        end
       end
      else
      local m=self.db.market[keys[i]];i=i+1
      if m and type(m.name)=='string' and (m.name:lower():find(needle,1,true) or tostring(m.itemID)==needle) then
        local obs=self:PriceObservation(m.marketKey)
        local fresh=obs and not obs.unverified and time()-obs.at<=self.db.settings.maxDataAge
        local week,month=self:MarketWindow(m,7),self:MarketWindow(m,30)
        out[#out+1]={marketKey=m.marketKey,itemID=m.itemID,name=m.name,floor=obs and obs.floor or 0,
          fair=m.fairValue or 0,quantity=m.latest and m.latest.quantity or 0,
          median7=week and week.median,median30=month and month.median,
          confidence=m.confidence or 'Unknown',modelReady=self:CanEstimateResale(m),
          status=not fresh and 'STALE' or obs.source=='Synced account' and 'SHARED*' or self:CanEstimateResale(m) and 'CACHED' or 'UNPROVEN'}
      end
      end
      if debugprofilestop()-start>=4 then return false end
    end
  end,function()
    if token~=self.browseToken then return end
    self.browseRows=out;self:SortBrowseRows();self:RefreshUI()
  end)
end

-- Each full scan is one sample; a 7/30-day median treats scans equally, not
-- thousands of correlated listings as thousands of independent observations.
function M:MarketWindow(m,days)
  if type(m)~='table' or type(m.history)~='table' then return nil end
  local values,now={},time()
  for _,h in ipairs(m.history) do
    if type(h)=='table' and self:Finite(h.at,now-days*86400,now+300)
      and self:Finite(h.median,1,1e12) then
      values[#values+1]=h.median
    end
  end
  if #values==0 then return nil end
  table.sort(values)
  local n=#values
  local med=n%2==1 and values[(n+1)/2] or (values[n/2]+values[n/2+1])/2
  return {median=math.floor(med+0.5),samples=n,low=values[1],high=values[n]}
end
function M:GetSniperRows(filter,sort)
  local out={}
  local q=tostring(filter or ''):lower()
  for _,o in ipairs(self.db.opportunities or {}) do
    if type(o)=='table' and type(o.name)=='string' and o.name:lower():find(q,1,true) then
      out[#out+1]=o
    end
  end
  local function metric(o)
    if sort=='profit' then return o.economics and o.economics.net or 0 end
    if sort=='roi' then return o.economics and o.economics.roi or 0 end
    if sort=='confidence' then return o.confidenceScore or 0 end
    if sort=='liquidity' then return o.activityScore or 0 end
    if sort=='discount' then return o.economics and o.economics.discount or 0 end
    if sort=='ask' then return o.floor or 0 end
    return o.score or 0
  end
  table.sort(out,function(a,b)
    if sort=='name' then
      if a.name~=b.name then return a.name<b.name end
    else
      local av,bv=metric(a),metric(b)
      if av~=bv then return av>bv end
    end
    return tostring(a.marketKey)<tostring(b.marketKey)
  end)
  return out
end

-- Player-reviewed shortlist. Queue entries NEVER imply a valid quote, a reserved
-- transaction, or a completed purchase; every row must be revalidated live.
function M:QueuePurchaseReview(opportunity)
  if self.persistenceBlocked then return false,'Newer database schema; queue disabled' end
  if type(opportunity)~='table' or not opportunity.marketKey then return false,'Select an opportunity first' end
  local m=self.db.market[opportunity.marketKey]
  if not m then return false,'Market unavailable' end
  local list=self.db.reviewQueue
  local count=0;for _ in pairs(list) do count=count+1 end
  if not list[opportunity.marketKey] and count>=100 then return false,'Review queue limited to 100 items' end
  list[opportunity.marketKey]={marketKey=opportunity.marketKey,itemID=m.itemID,
    name=m.name,queuedAt=time(),snapshotAsk=opportunity.floor,
    snapshotROI=opportunity.economics and opportunity.economics.roi or 0}
  self:RefreshUI()
  return true
end
function M:RemovePurchaseReview(key)
  if self.persistenceBlocked or key==nil then return false end
  self.db.reviewQueue[key]=nil
  self:RefreshUI()
  return true
end
function M:GetPurchaseReviewRows()
  local out,opps={},{}
  for _,o in ipairs(self.db.opportunities or {}) do
    if type(o)=='table' and o.marketKey then opps[tostring(o.marketKey)]=o end
  end
  for key,item in pairs(self.db.reviewQueue or {}) do
    if type(item)=='table' and item.marketKey then
      local m=self.db.market[item.marketKey]
      local o=opps[tostring(item.marketKey)]
      local fresh=m and not m.analysisIncomplete and self:MarketFresh(m)
      local valid=fresh and o and o.pass
      out[#out+1]={marketKey=item.marketKey,itemID=item.itemID,
        name=m and m.name or item.name or ('Item '..tostring(item.itemID)),
        snapshotAsk=item.snapshotAsk or 0,ask=o and o.floor or 0,
        roi=o and o.economics and o.economics.roi or item.snapshotROI or 0,
        fair=m and m.fairValue or 0,confidence=o and o.confidence or 'Unknown',
        status=valid and 'REVALIDATE' or 'RECHECK',opportunity=valid and o or nil,
        queuedAt=item.queuedAt or 0}
    end
  end
  table.sort(out,function(x,y)
    if x.queuedAt~=y.queuedAt then return x.queuedAt>y.queuedAt end
    return tostring(x.name)<tostring(y.name)
  end)
  return out
end
