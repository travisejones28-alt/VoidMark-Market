local _,M=...
-- Advisory-only selling plans. No posting/cancel API is invoked by this module.
local STRATEGIES={'competitive','quick','median','margin'}
function M:GetSellStrategies() return STRATEGIES end
function M:SetSellStrategy(strategy)
  if self.persistenceBlocked then return false,'Newer database schema; changes disabled' end
  local found=false
  for _,s in ipairs(STRATEGIES) do if s==strategy then found=true; break end end
  if not found then return false,'Unknown selling strategy' end
  self.db.settings.sellStrategy=strategy
  self:RefreshInventory(); self:RefreshUI()
  return true
end
function M:SetSellFloor(key,copper)
  if self.persistenceBlocked then return false,'Newer database schema; changes disabled' end
  if not self.db.market[key] and not self:ParseKey(key) then return false,'Market variant unavailable' end
  if copper~=nil and (not self:Finite(copper,1,1e12) or copper%1~=0) then
    return false,'Enter a positive price in copper'
  end
  local floors=self.db.sellFloors
  local count=0
  for _ in pairs(floors) do count=count+1 end
  if floors[key]==nil and copper~=nil and count>=300 then return false,'300 per-item floors maximum' end
  floors[key]=copper
  self:RefreshInventory(); self:RefreshUI()
  return true
end
function M:BuildSellPlan(key,quantity)
  local m=key and self.db.market[key]
  local p={marketKey=key,quantity=quantity,price=nil,status='NO DATA',
    reason='No exact-variant market history; review the native Auction House.',
    basisKnown=false,depositEstimated=true}
  if not m or type(m.latest)~='table' then return p end
  p.itemID=m.itemID;p.name=m.name
  p.floor=m.latest.floor
  p.confidence=m.confidence or 'Unknown'
  if not self:Finite(quantity,1,1e6) or quantity%1~=0 then
    p.status='INVALID'; p.reason='Invalid bag stack quantity'; return p
  end
  if m.analysisIncomplete or m.cacheUntrusted or not self:MarketFresh(m)
    or not self:Finite(m.fairValue,1,1e12) then
    p.status='STALE';p.reason='Untrusted, incomplete or outdated market valuation. Do not auto-price.'
    return p
  end
  local supported,reason=self:CanEstimateResale(m)
  if not supported then
    p.status='UNPROVEN';p.reason=reason..'; asking prices remain visible in Browse. Verify live competition in the native AH.'
    return p
  end
  p.fair=m.fairValue
  local fair=m.fairValue
  local depth=m.latest.meaningfulFloor or m.latest.q10 or fair
  if not self:Finite(depth,1,1e12) then depth=fair end
  local settings=self.db.settings
  local strategy=settings.sellStrategy
  if strategy~='quick' and strategy~='median' and strategy~='margin' then strategy='competitive' end
  local price
  if strategy=='quick' then price=math.min(fair*0.90,depth*0.98)
  elseif strategy=='median' then price=fair
  elseif strategy=='margin' then price=math.max(fair*1.10,depth)
  else price=math.min(fair,depth)-1 end
  price=math.max(1,math.floor(price+0.5))
  p.strategy=strategy
  local own
  for _,r in ipairs(self.ownedRows or {}) do
    if r.marketKey==key and self:Finite(r.unit,1,1e12) then
      own=not own and r.unit or math.min(own,r.unit)
    end
  end
  if own then price=math.max(price,math.ceil(own)) end
  p.own=own
  local custom=self.db.sellFloors and self.db.sellFloors[key]
  if self:Finite(custom,1,1e12) then
    p.customFloor=custom;price=math.max(price,custom)
  end
  local lot=self.db.inventory and self.db.inventory[self:InventoryKey(key)]
  local basis
  if type(lot)=='table' and lot.character==self.characterID and
    self:Finite(lot.quantity,0.00001,1e9) and self:Finite(lot.cost,0,1e14) then
    basis=lot.cost/lot.quantity
    if self:Finite(basis,0,1e12) then
      p.basisUnit=basis
      p.basisKnown=lot.quantity>=quantity
      p.coveredQuantity=math.min(lot.quantity,quantity)
    end
  end
  local cut=settings.ahCut or 0.05
  if not self:Finite(cut,0,0.30) then cut=0.05 end
  local deposit=settings.depositReserve or 0
  if not self:Finite(deposit,0,1e9) then deposit=0 end
  local margin=settings.sellMinMargin or 0
  if not self:Finite(margin,0,2) then margin=0 end
  if basis then
    p.minimumBreakEven=math.ceil((basis*(1+margin)+deposit)/(1-cut))
    price=math.max(price,p.minimumBreakEven)
  end
  if not self:Finite(price,1,1e12) then
    p.status='INVALID';p.reason='Calculated price exceeds supported bounds';return p
  end
  p.price=price;p.depositAllowance=math.ceil(deposit*quantity)
  p.gross=price*quantity
  p.estimatedCut=math.ceil(p.gross*cut)
  p.estimatedNet=p.gross-p.estimatedCut-p.depositAllowance
  if p.estimatedNet<=0 then
    p.status='NO RETURN';p.reason='Estimated AH fees and deposit allowance consume the proceeds. Check the actual native deposit before posting.'
    p.price=nil;p.estimatedNet=nil;p.gross=nil;p.estimatedCut=nil;p.depositAllowance=nil
    return p
  end
  p.profit=p.basisKnown and p.estimatedNet-basis*quantity or nil
  p.roi=p.profit and basis*quantity>0 and p.profit/(basis*quantity) or nil
  local risks={}
  if self:Finite(m.latest.floor,1,1e12) and m.latest.floor<depth*0.75 then
    risks[#risks+1]='Very low listing may be isolated price bait'
  end
  if (m.observations or 0)<3 then risks[#risks+1]='Less than three independent scans' end
  if (m.confidenceScore or 0)<(settings.minConfidence or 42) then risks[#risks+1]='Low model confidence' end
  if (m.volatility or 0)>(settings.riskTolerance or 0.35) then risks[#risks+1]='High price volatility' end
  if not p.basisKnown then
    risks[#risks+1]=basis and 'Only part of this stack has known acquisition cost' or 'Acquisition cost unknown (possibly gathered/mailed)'
  end
  if own then risks[#risks+1]='Your own existing auction price is protected against self-undercutting' end
  if price>fair*1.35 then
    p.status='HOLD'
    risks[#risks+1]='Floor/breakeven requires a price far above fair value'
  elseif #risks>0 then p.status='REVIEW'
  else p.status='ESTIMATE' end
  p.reason=table.concat(risks,'; ')
  if p.reason=='' then p.reason='Snapshot-based suggestion; verify live prices and native AH deposit before posting' end
  return p
end

-- Repricing is always a review signal. No cancellation or native post is made.
function M:AssessOwnedRepost(row,competitor,cancelCost)
  local out={action='HOLD',reason='Insufficient information to justify cancel/repost'}
  if type(row)~='table' or not self:Finite(row.unit,1,1e12)
    or not self:Finite(row.quantity,1,1e6) then return out end
  if not self:Finite(competitor,1,1e12) then
    out.reason='Nobody else is selling this. Keep it.'
    return out
  end
  if competitor>=row.unit then
    out.reason="You're still the cheapest. Keep it."
    return out
  end
  local market=self.db.market[row.marketKey]
  if not self:CanEstimateResale(market) then
    out.reason='Not enough price history to judge. Keep it for now.'
    return out
  end
  local anchor=market.latest and (market.latest.meaningfulFloor or market.latest.q10)
  if self:Finite(anchor,1,1e12) and competitor<anchor*0.75 then
    out.reason='Undercut looks like a bait price far below normal. Keep it.'
    return out
  end
  local reducedUnit=math.max(1,math.floor(competitor-1))
  local revenueDecrease=math.ceil((row.unit-reducedUnit)*row.quantity)
  out.proposedUnit=reducedUnit;out.revenueDecrease=revenueDecrease
  if not self:Finite(cancelCost,0,1e12) or not self:Finite(row.deposit,0,1e12) then
    out.reason='Undercut, but the cancel cost is unknown. Keep it for now.'
    return out
  end
  local totalFriction=cancelCost+row.deposit
  local gap=(row.unit-competitor)/row.unit
  out.action=gap>=0.15 and 'REVIEW' or 'HOLD'
  out.reason=string.format('Undercut %.0f%% (cheapest now %s). %s',gap*100,self:Money(competitor),
    out.action=='REVIEW' and 'Worth cancelling and reposting.' or 'Small gap: keep it.')
  return out
end

-- Posting intents are bookmarks, NOT executable bag slots or price commitments.
-- Each visit re-reads current bags. This does not invoke native AH posting.
function M:QueuePostingReview(plan)
  if self.persistenceBlocked then return false,'Newer schema; queue disabled' end
  if type(plan)~='table' or not plan.marketKey or not self.db.market[plan.marketKey] then
    return false,'Select a market-matched bag item'
  end
  if not self:Finite(plan.quantity,1,1e6) then return false,'Invalid quantity' end
  local index=self.characterID..'/'..tostring(plan.marketKey)
  local count=0;for _ in pairs(self.db.postQueue) do count=count+1 end
  if not self.db.postQueue[index] and count>=100 then return false,'Posting queue is full (100)' end
  self.db.postQueue[index]={character=self.characterID,marketKey=plan.marketKey,
    itemID=plan.itemID,name=plan.name,quantity=plan.quantity,queuedAt=time(),
    snapshotUnit=plan.price,notes='No confirmed posting; advisory only'}
  self:RefreshUI()
  return true
end
function M:RemovePostingReview(key)
  if self.persistenceBlocked then return false end
  self.db.postQueue[self.characterID..'/'..tostring(key)]=nil
  self:RefreshUI()
  return true
end
function M:GetPostingReviewRows()
  local present={}
  for _,row in ipairs(self.sellingRows or {}) do
    if row.marketKey and row.bag~=nil and row.slot~=nil then
      local id=tostring(row.marketKey)
      if not present[id] or (row.quantity or 0)>(present[id].quantity or 0) then present[id]=row end
    end
  end
  local out={}
  for _,entry in pairs(self.db.postQueue or {}) do
    if type(entry)=='table' and entry.character==self.characterID and entry.marketKey then
      local current=present[tostring(entry.marketKey)]
      local status=not current and 'CHECK BAGS' or not current.price and 'NO PRICE' or
        current.status=='HOLD' and 'HOLD' or 'REVIEW'
      out[#out+1]={marketKey=entry.marketKey,itemID=entry.itemID,
        name=current and current.name or entry.name or 'Unknown item',
        quantity=current and current.quantity or 0,snapshotUnit=entry.snapshotUnit,
        price=current and current.price or nil,
        fair=current and current.fair or nil,status=status,queuedAt=entry.queuedAt or 0,
        reason=current and current.reason or 'Item not observed in most recent bag scan; refresh inventory',
        bag=current and current.bag,slot=current and current.slot}
    end
  end
  table.sort(out,function(a,b)
    if a.queuedAt~=b.queuedAt then return a.queuedAt>b.queuedAt end
    return tostring(a.name)<tostring(b.name)
  end)
  return out
end
