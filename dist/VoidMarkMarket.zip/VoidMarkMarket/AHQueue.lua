local _,M=...
M.queue={waiting={},dedupe={},stats={sent=0,timeouts=0,retries=0,dropped=0},sequence=0,nextSend=0}
function M:ThrottleReady()
  if not self:CanUseAuctionHouse() then return false end
  local fn=C_AuctionHouse.IsThrottledMessageSystemReady
  if type(fn)~='function' then return true end
  local ok,v=pcall(fn); return ok and v==true
end
function M:QueueRequest(r)
  if not self:CanUseAuctionHouse() then if r.fail then r.fail('Auction House closed') end; return false end
  local q=self.queue
  local old=q.dedupe[r.id]
  if old and old.kind=='search' and r.kind=='search' then return self:JoinSearch(old,r) end
  if old then if r.fail then r.fail('A search for this item is already running') end; return false,'duplicate' end
  if #q.waiting>=100 then if r.fail then r.fail('Queue full') end; return false end
  q.sequence=q.sequence+1; r.token=q.sequence; r.priority=r.priority or 10; r.at=GetTime(); r.attempt=0
  q.dedupe[r.id]=r; q.waiting[#q.waiting+1]=r
  table.sort(q.waiting,function(a,b) if a.priority==b.priority then return a.token<b.token end; return a.priority>b.priority end)
  self:RefreshUI(); return true
end
-- A second search for an item already queued or running (a price check, the
-- last buy page, the next buy in a chain) rides along with it instead of failing.
-- A buy needs fresh listings, so a joined price check stops using cached results.
function M:JoinSearch(old,r)
  local d1,f1,v1,d2,f2,v2=old.done,old.fail,old.valid,r.done,r.fail,r.valid
  old.done=function(x) if d1 then pcall(d1,x) end; if d2 then d2(x) end end
  old.fail=function(x) if f1 then pcall(f1,x) end; if f2 then f2(x) end end
  if v1 and v2 then old.valid=function() return v1() or v2() end else old.valid=nil end
  if not r.allowCached and old.allowCached then
    old.allowCached=nil
    if old.polled and not old.reading then old.polled=nil; old.fresh=true; old.resend=true; old.more=nil; old.sent=GetTime() end
  end
  if (r.priority or 0)>(old.priority or 0) then
    old.priority=r.priority
    table.sort(self.queue.waiting,function(a,b) if a.priority==b.priority then return a.token<b.token end; return a.priority>b.priority end)
  end
  self:RefreshUI(); return true
end
function M:FinishRequest(r,ok,result)
  local q=self.queue; if q.active~=r then return end
  q.active=nil; q.dedupe[r.id]=nil; self:CancelJob('results')
  q.nextSend=GetTime()+0.3
  if ok then if r.done then r.done(result) end else if r.fail then r.fail(result) end end
  self:RefreshUI()
end
function M:CancelRequests(reason)
  local q=self.queue; local old=q.active; q.active=nil; q.dedupe={}
  local waiting=q.waiting; q.waiting={}; self:CancelJob('results')
  if q.lateReplicate then
    if q.lateReplicate.fail then q.lateReplicate.fail(reason) end
    q.lateReplicate=nil
  end
  if old and old.fail then old.fail(reason) end
  for _,r in ipairs(waiting) do if r.fail then r.fail(reason) end end
end
function M:SendAHRequest(r)
  local A=C_AuctionHouse
  if r.kind=='replicate' then
    self:FullScanSent(r)
    self.db.lastFreshScanRequestAt=time(); A.ReplicateItems()
  elseif r.kind=='owned' then A.QueryOwnedAuctions({})
  elseif r.kind=='browse' then A.SendBrowseQuery(r.query)
  elseif r.kind=='browsemore' then A.RequestMoreBrowseResults()
  elseif r.kind=='search' then
    local has=A.HasSearchResults and A.HasSearchResults(r.key)
    if r.more then
      if r.commodity then A.RequestMoreCommoditySearchResults(r.key.itemID) else A.RequestMoreItemSearchResults(r.key) end
    elseif has and not r.fresh and r.commodity and A.RefreshCommoditySearchResults then r.refreshed=true;A.RefreshCommoditySearchResults(r.key.itemID)
    elseif has and not r.fresh and not r.commodity and A.RefreshItemSearchResults then r.refreshed=true;A.RefreshItemSearchResults(r.key)
    elseif has and not r.fresh then error('Fresh search refresh API missing; close and reopen AH')
    else
      local sorts={}; if Enum and Enum.AuctionHouseSortOrder then sorts={{sortOrder=Enum.AuctionHouseSortOrder.Price,reverseSort=false}} end
      A.SendSearchQuery(r.key,sorts,true)
    end
  end
end
function M:PumpQueue()
  local q=self.queue; if not self:CanUseAuctionHouse() then return end
  local r=q.active
  if r and r.kind=='replicate' then
    local elapsed=GetTime()-r.sent
    if elapsed>=180 then
      if not r.timedOut then r.timedOut=true; q.stats.timeouts=q.stats.timeouts+1 end
      q.lateReplicate=r -- keep correlation until AH close, cached analysis or a new full scan
      self:FinishRequest(r,false,self:FullScanTimeoutReason(r)); return
    elseif elapsed>=r.timeout and not r.timedOut then
      r.timedOut=true; q.stats.timeouts=q.stats.timeouts+1
      self:FullScanSlow(r)
    end
  elseif r and GetTime()-r.at>90 then self:FinishRequest(r,false,'Request total deadline exceeded'); return
  elseif r and GetTime()-r.sent>(r.refreshed and not r.allowCached and not r.more and 5 or r.timeout) then
    q.stats.timeouts=q.stats.timeouts+1
    if r.kind~='replicate' and r.attempt<2 and not r.reading then
      r.attempt=r.attempt+1; r.sent=GetTime(); r.resend=true; r.polled=nil; q.stats.retries=q.stats.retries+1
      -- Forever sometimes ignores a refresh of an item already searched: retry with a new search.
      if r.refreshed then r.refreshed=nil; r.fresh=true end
    else self:FinishRequest(r,false,'Request timed out; no fresh response'); return end
  end
  if self.execution and (self.execution.state=='quoting' or self.execution.state=='quoted' or self.execution.state=='pending') then return end
  if r and self:PreemptForBuy(r) then r=nil end
  if r then
    self:PollSearch(r)
    if r.resend and self:ThrottleReady() then
      r.resend=nil; local ok,err=pcall(self.SendAHRequest,self,r)
      if not ok then self:FinishRequest(r,false,tostring(err)) end
    end
    return
  end
  if GetTime()<q.nextSend or not self:ThrottleReady() then return end
  -- While you're on an item's buy page, background search-term pages wait so
  -- the item's own listing search goes out next and nothing competes with it.
  local hold=self.shopBuy~=nil
  local i=1
  while q.waiting[i] do
    local w=q.waiting[i]
    if hold and type(w.id)=='string' and w.id:find('^browse%-term:') then w.at=GetTime();i=i+1
    else
      r=table.remove(q.waiting,i)
      if r.valid and not r.valid() or GetTime()-r.at>120 then
        q.dedupe[r.id]=nil; if r.fail then r.fail('Stale request cancelled') end
      else break end
      r=nil
    end
  end
  if not r then return end
  q.active=r; r.sent=GetTime(); r.timeout=r.kind=='replicate' and 60 or 15; r.attempt=1
  local ok,err=pcall(self.SendAHRequest,self,r)
  if not ok then self:FinishRequest(r,false,tostring(err)) else q.stats.sent=q.stats.sent+1 end
end
-- On an item's buy page, its listing search must not wait behind a background
-- request already in flight (a search-term page, your auctions, a price check).
-- Put that request back in line and send the buy search now.
local BACKGROUND={browse=true,browsemore=true,owned=true}
function M:PreemptForBuy(r)
  local q=self.queue
  if not self.shopBuy or r.reading then return false end
  if not (BACKGROUND[r.kind] or (r.kind=='search' and r.allowCached)) then return false end
  local buy=false
  for _,w in ipairs(q.waiting) do if w.kind=='search' and not w.allowCached and w.priority>=90 then buy=true;break end end
  if not buy then return false end
  q.active=nil; self:CancelJob('results')
  r.preempted=true; r.resend=nil; r.more=nil; r.refreshed=nil; r.polled=nil; r.at=GetTime(); r.attempt=0
  table.insert(q.waiting,r)
  table.sort(q.waiting,function(a,b) if a.priority==b.priority then return a.token<b.token end; return a.priority>b.priority end)
  return true
end
function M:Search(m,priority,done,fail,valid,allowCached)
  local key=self:ItemKey(m); local commodity=self:IsCommodity(key)
  if commodity==nil then if fail then fail('Commodity classification unavailable; wait for item data') end; return false end
  return self:QueueRequest({id='search:'..tostring(self:Key(key.itemID,key.itemSuffix,key.itemLevel,key.battlePetSpeciesID)),kind='search',
    key=key,commodity=commodity,priority=priority,done=done,fail=fail,valid=valid,allowCached=allowCached})
end
-- Forever sometimes answers a refresh of an item already searched this session
-- without a "results updated" event. For price checks that only fill the sell
-- price (never purchases), read the client's complete results after a short wait.
function M:PollSearch(r)
  if not r or r.kind~='search' or not r.allowCached or r.reading or r.resend or r.polled then return end
  if GetTime()-(r.sent or 0)<2.5 then return end
  local A=C_AuctionHouse; local arg=r.commodity and r.key.itemID or r.key
  local fullFn=r.commodity and A.HasFullCommoditySearchResults or A.HasFullItemSearchResults
  if type(fullFn)~='function' then return end
  local ok,full=pcall(fullFn,arg)
  if ok and full then r.polled=true; self:ReadSearch('poll',arg) end
end
function M:ReadSearch(event,key)
  local r=self.queue.active
  if not r or r.kind~='search' or r.resend then return end
  if r.commodity then if tonumber(key)~=r.key.itemID then return end
  elseif not self:SameKey(key,r.key) then return end
  -- UPDATED/ADDED may arrive repeatedly. Restart only this request's bounded reader.
  r.reading=true
  local A=C_AuctionHouse; local arg=r.commodity and r.key.itemID or r.key
  local fullFn=r.commodity and A.HasFullCommoditySearchResults or A.HasFullItemSearchResults
  if type(fullFn)~='function' then self:FinishRequest(r,false,'Cannot verify complete search results'); return end
  local ok,full=pcall(fullFn,arg)
  if not ok then self:FinishRequest(r,false,'Full-results API failed'); return end
  if not full then
    r.reading=false; r.more=true; r.resend=true; r.sent=GetTime(); r.pages=(r.pages or 0)+1
    if r.pages>30 then self:FinishRequest(r,false,'Pagination limit; incomplete results cannot execute'); return end
    local more=r.commodity and A.RequestMoreCommoditySearchResults or A.RequestMoreItemSearchResults
    if type(more)~='function' then self:FinishRequest(r,false,'Search incomplete and pagination unavailable') end
    return
  end
  r.more=nil
  local countFn=r.commodity and A.GetNumCommoditySearchResults or A.GetNumItemSearchResults
  local infoFn=r.commodity and A.GetCommoditySearchResultInfo or A.GetItemSearchResultInfo
  local good,n=pcall(countFn,arg)
  if not good or not tonumber(n) then self:FinishRequest(r,false,'Invalid search count'); return end
  if n>1000 then self:FinishRequest(r,false,'More than 1,000 live tiers/listings; execution paused to protect frame budget'); return end
  local result={key=r.key,commodity=r.commodity,rows={},all={},at=time(),received=GetTime(),full=true}; local i=1
  self:AddJob('results',function(start)
    if self.queue.active~=r then return true end
    for j=1,70 do
      if i>n then return true end
      local valid,info=pcall(infoFn,arg,i); i=i+1
      if not valid or type(info)~='table' then result.incomplete=true
      else
        local qty=r.commodity and tonumber(info.quantity) or self:RegularQuantity(info,r.key.itemID); local total=tonumber(info.buyoutAmount)
        local unit=r.commodity and tonumber(info.unitPrice) or (total and qty and qty>0 and total/qty)
        local own=tonumber(info.numOwnerItems) or 0
        if unit and unit>0 and qty and qty>0 and #result.all<300 then
          local mine=r.commodity and (own>0 or (info.containsOwnerItem and info.numOwnerItems==nil)) or (not r.commodity and (info.isOwnerItem or info.containsOwnerItem)) or false
          result.all[#result.all+1]={unit=unit,quantity=qty,own=mine and true or false}
        end
        if r.commodity and info.containsOwnerItem and info.numOwnerItems==nil then qty=0 end
        if r.commodity then qty=qty and math.max(0,qty-own) end
        if unit and unit>0 and qty and qty>0 and (r.commodity or (info.auctionID and not info.isOwnerItem and not info.containsOwnerItem and (not info.itemKey or self:SameKey(info.itemKey,r.key)))) then
          result.rows[#result.rows+1]={unit=unit,quantity=qty,total=r.commodity and unit*qty or total,auctionID=info.auctionID,itemLink=info.itemLink}
        end
      end
      if debugprofilestop()-start>=4 then return false end
    end
  end,function()
    if self.queue.active~=r then return end
    if result.incomplete then self:FinishRequest(r,false,'Incomplete search rows; revalidate again'); return end
    table.sort(result.rows,function(a,b) return a.unit<b.unit end)
    table.sort(result.all,function(a,b) if a.unit==b.unit then return a.own and not b.own end return a.unit<b.unit end)
    if self.RecordSearchResult then pcall(self.RecordSearchResult,self,result) end
    self:FinishRequest(r,true,result)
  end)
end
for _,event in ipairs({'ITEM_SEARCH_RESULTS_UPDATED','ITEM_SEARCH_RESULTS_ADDED','COMMODITY_SEARCH_RESULTS_UPDATED','COMMODITY_SEARCH_RESULTS_ADDED'}) do
  M:RegisterHandler(event,function(self,e,key) self:ReadSearch(e,key) end)
end
M:RegisterHandler('OWNED_AUCTIONS_UPDATED',function(self)
  local r=self.queue.active; if r and r.kind=='owned' then self:FinishRequest(r,true,true) end
end)
M:RegisterHandler('AUCTION_HOUSE_BROWSE_RESULTS_UPDATED',function(self)
  local r=self.queue.active; if r and (r.kind=='browse' or r.kind=='browsemore') then self:FinishRequest(r,true,true) end
end)
M:RegisterHandler('AUCTION_HOUSE_BROWSE_FAILURE',function(self)
  local r=self.queue.active; if r and (r.kind=='browse' or r.kind=='browsemore') then self:FinishRequest(r,false,'Auction House search failed') end
end)
M:RegisterHandler('AUCTION_HOUSE_BROWSE_RESULTS_ADDED',function(self)
  local r=self.queue.active; if r and r.kind=='browsemore' then self:FinishRequest(r,true,true) end
end)
-- The AH sends browse results a page at a time. After a browse finishes, ask
-- for the next page (ahead of other searches, so the browse is not replaced)
-- until it is complete or maxPages is reached. Returns true when a page was queued.
M.BROWSE_MAX_PAGES=40
function M:BrowseNeedsMore(pages)
  local A=C_AuctionHouse
  if not (A and A.HasFullBrowseResults and A.RequestMoreBrowseResults) then return false end
  return not A.HasFullBrowseResults() and (pages or 1)<self.BROWSE_MAX_PAGES
end
function M:QueueBrowseMore(id,done,fail)
  return self:QueueRequest({id=id..':more',kind='browsemore',priority=60,done=done,fail=fail})
end
M:RegisterHandler('AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED',function(self)
  self.queue.stats.dropped=self.queue.stats.dropped+1
  local r=self.queue.active; if r then self:FinishRequest(r,false,'AH throttle dropped request') end
end)
-- Once every auction has been read, saving the prices needs no Auction House:
-- let it finish. Closing earlier left half the items with yesterday's prices.
function M:ScanSurvivesClose()
  local s=self.scanState
  return s and s.running and s.phase=='model' and (self.jobs.model or self.jobs['scan-finish']) and true or false
end
M:RegisterHandler('AUCTION_HOUSE_CLOSED',function(self)
  self:CancelRequests('Auction House closed')
  if self:ScanSurvivesClose() then self:SetScanStatus('Saving scan results (Auction House closed is fine)',0.9); return end
  self.scanToken=(self.scanToken or 0)+1; self:CancelJob('scan'); self:CancelJob('model'); self:CancelJob('scan-finish')
end)
