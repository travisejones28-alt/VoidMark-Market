local _,M=...
M.sellingRows={}; M.ownedRows={}
function M:RefreshInventory()
  if not C_Container or type(C_Container.GetContainerItemInfo)~='function'
    or type(C_Container.GetContainerNumSlots)~='function' then self.sellingRows={};return end
  -- Your Items used to blank and restart on every bag/item-data event (the
  -- list was cleared first, then rebuilt over a few frames), so it flashed or
  -- stayed empty. Now the old list stays up until the new one is complete,
  -- and a refresh asked for mid-build runs once after it finishes.
  if self.jobs and self.jobs.bags then self.bagsAgain=true;return end
  local bag,slot=0,1; local rows={}
  self:AddJob('bags',function(start)
    for j=1,25 do
      if bag>4 then return true end
      local ok,count=pcall(C_Container.GetContainerNumSlots,bag)
      if not ok or not self:Finite(count,0,200) then
        -- Never present a partial inventory as a complete pricing result.
        rows={};self:Log('SELL','Bag slot query unavailable; pricing cancelled');return true
      end
      if slot>count then bag=bag+1;slot=1
      else
        local currentBag,currentSlot=bag,slot;slot=slot+1
        local success,info=pcall(C_Container.GetContainerItemInfo,currentBag,currentSlot)
        if success and type(info)=='table' and info.itemID and not info.isBound then
          local key=self:LinkIdentity(info.hyperlink,info.itemID)
          local qty=tonumber(info.stackCount) or 1
          if self:Finite(qty,1,1e6) and qty%1==0 then
            local plan=key and self:BuildSellPlan(key,qty) or
              {marketKey=nil,quantity=qty,status='VARIANT UNKNOWN',
               reason='Item hyperlink or variant unavailable; cannot select a safe price'}
            local m=key and self.db.market[key]
            plan.itemID=info.itemID
            plan.name=m and m.name or info.itemName or (GetItemInfo and GetItemInfo(info.itemID)) or
              ('Item '..tostring(info.itemID))
            -- Forever's links drop the suffix, so a scan can file another suffix's
            -- price under this item. Use the real name from the item's tooltip and
            -- never offer a price that belongs to a different suffix.
            local full=self.BagItemFullName and self:BagItemFullName(currentBag,currentSlot)
            if full then
              local state,sf=self:VariantPrice(key,full,self:LinkName(info.hyperlink))
              if state=='suffix' then
                plan.price=sf.floor;plan.suffixPrice=sf.floor;plan.reason='Last scan price for this suffix'
              elseif state=='none' then
                plan.variantMismatch=m and m.name or true;plan.price=nil;plan.reason='No scan price for this suffix yet'
              end
              plan.name=full
            end
            -- The AH's own key for this exact item (with its suffix): used for
            -- your settings, post history and what you paid, so suffixes never share.
            local ahKey=self:BagAHKey(currentBag,currentSlot,info.itemID)
            if ahKey~=nil and ahKey~=key then plan.linkKey=key;plan.marketKey=ahKey end
            plan.quantity=qty;plan.bag=currentBag;plan.slot=currentSlot
            plan.itemLink=info.hyperlink
            plan.icon=info.iconFileID
            plan.confidence=plan.confidence or 'Unknown'
            plan.stale=not plan.price
            rows[#rows+1]=plan
          end
        end
      end
      if debugprofilestop()-start>=4 then return false end
    end
  end,function()
    table.sort(rows,function(a,b)
      if (a.price~=nil)~=(b.price~=nil) then return a.price~=nil end
      return tostring(a.name)<tostring(b.name)
    end)
    self.sellingRows=rows
    if self.AfterPostRefresh then self:AfterPostRefresh(rows) end
    if self.bagsAgain then self.bagsAgain=nil;self.bagsDirty=true end
    self:RefreshUI()
  end)
end
function M:RequestOwnedAuctionsDiagnostic()
  -- You're looking at Listings and waiting: ahead of list/name searches (only a
  -- purchase you're in the middle of, priority 90, goes first).
  self:QueueRequest({id='owned',kind='owned',priority=85,done=function() M:CaptureOwnedAuctions() end,
    fail=function(e) M:Log('OWNED',e); M:Print(e) end})
end
-- Price each for one of your listings. Forever is not consistent: a stack of
-- Rosecap gave buyoutAmount per item, a stack of 15 Silk Cloth gave the whole
-- stack's price (alert said 4g 32s for 28s 80c). For a stack, pick whichever
-- reading (as-is or divided by the quantity) is closer to a price we know:
-- your last post of it, else the market floor. Only fall back to the
-- commodity flag when there is nothing to compare with.
function M:OwnedUnitPrice(info,key,qty,m,keepIfUnknown)
  local buyout=tonumber(info.buyoutAmount) or 0
  if qty<=1 or buyout<=0 then return buyout end
  local divided=buyout/qty
  local ref
  local hist=type(self.db.postHistory)=='table' and self.db.postHistory[key]
  if type(hist)=='table' and hist[1] and self:Finite(hist[1].unit,1,1e12) then ref=hist[1].unit end
  if not ref and m and m.latest and self:Finite(m.latest.floor,1,1e12) then ref=m.latest.floor end
  if not ref and m and self:Finite(m.fairValue,1,1e12) then ref=m.fairValue end
  if ref then
    local function off(v) return math.abs(math.log(v/ref)) end
    return off(divided)<off(buyout) and divided or buyout
  end
  if keepIfUnknown then return buyout end
  return self:IsCommodity(info.itemKey)==true and buyout or divided
end
function M:CaptureOwnedAuctions()
  local A=C_AuctionHouse; local rows={}; local n=0
  local all
  if A.GetOwnedAuctions then local ok,v=pcall(A.GetOwnedAuctions); if ok and type(v)=='table' then all=v; n=#v end end
  if not all and A.GetNumOwnedAuctions then local ok,v=pcall(A.GetNumOwnedAuctions); if ok then n=tonumber(v) or 0 end end
  local i=1
  self:AddJob('owned',function(start)
    for j=1,40 do
      if i>n then return true end
      local info=all and all[i]; if not all and A.GetOwnedAuctionInfo then local ok,v=pcall(A.GetOwnedAuctionInfo,i); if ok then info=v end end
      i=i+1
      if type(info)=='table' and type(info.itemKey)=='table' then
        local key=self:Key(info.itemKey.itemID,info.itemKey.itemSuffix,info.itemKey.itemLevel,info.itemKey.battlePetSpeciesID)
        local m=self.db.market[key]; local qty=tonumber(info.quantity) or 1
        -- Stackables (commodities): the AH gives the price per item already;
        -- dividing by the quantity again made 3 Rosecap at 15s 89c look like
        -- 5s 29c ("LOWEST" while undercut). Gear: the buyout is for the auction.
        local unit=tonumber(info.unitPrice)
        if not unit then unit=self:OwnedUnitPrice(info,key,qty,m) end
        rows[#rows+1]={auctionID=info.auctionID,itemKey=info.itemKey,itemID=info.itemKey.itemID,marketKey=key,name=self:OwnedAuctionName(key,m,info),quantity=qty,
          unit=unit,unitChecked=true,timeLeft=info.timeLeftSeconds or info.timeLeft,status=info.status,action='INSPECT',deposit=info.depositAmount,
          floor=m and m.latest and m.latest.meaningfulFloor,reason='Snapshot comparison only; refresh item before deciding'}
      end
      if debugprofilestop()-start>=4 then return false end
    end
  end,function() if self.CarryOwnedVerdicts then self:CarryOwnedVerdicts(self.ownedRows,rows) end
    self.ownedRows=rows; self.ownedLoadedAt=time(); if self.UpdateFlipListings then self:UpdateFlipListings(rows) end
    if not self.persistenceBlocked then
      -- Kept across reloads/logins so sale alerts know your listing prices.
      local snap={}
      for i=1,math.min(#rows,300) do local o=rows[i];snap[i]={auctionID=o.auctionID,name=o.name,unit=o.unit,unitChecked=true,quantity=o.quantity,marketKey=o.marketKey,status=o.status} end
      self.db.ownedSnapshot={at=time(),rows=snap}
    end; self:RefreshInventory(); self:RefreshUI() end)
end
function M:AnalyzeOwnedLive(row)
  local market=row and self.db.market[row.marketKey]
  if not market and row and row.itemKey then market=row.itemKey end
  if not market or not row.auctionID then
    if row then row.action='HOLD';row.reason='Cannot safely identify this auction or its variant' end
    self:RefreshUI();return
  end
  row.action='CHECKING';row.reason='Waiting for complete live search results'
  self:Search(market,60,function(result)
    -- ReadSearch already removes own commodity quantity and ignores own regular listings.
    local competitor=result.rows[1] and result.rows[1].unit
    local A=C_AuctionHouse;local cost=nil
    if type(A.GetCancelCost)=='function' then
      local ok,value=pcall(A.GetCancelCost,row.auctionID)
      if ok and self:Finite(value,0,1e12) then cost=value end
    end
    self:ApplyOwnedCompetition(row,competitor)
    row.cancelCost=cost
    local outcome=self:AssessOwnedRepost(row,competitor,cost)
    row.action=outcome.action;row.reason=outcome.reason
    row.proposedUnit=outcome.proposedUnit;row.repriceDifference=outcome.revenueDecrease
    self:SyncOwnedVerdict(row)
    self:RefreshUI()
  end,function(e)
    row.action='HOLD';row.reason='Live competitor search failed: '..tostring(e)
    self:SyncOwnedVerdict(row)
    self:RefreshUI()
  end)
end
M:RegisterHandler('BAG_UPDATE_DELAYED',function(self) self.bagsDirty=true end)
M:RegisterHandler('GET_ITEM_INFO_RECEIVED',function(self,_,id)
  if self.view~='selling' or not (self.window and self.window:IsShown()) then return end
  id=tonumber(id)
  for _,r in ipairs(self.sellingRows or {}) do
    -- Once per item: an item that never loads its name kept rebuilding the list.
    if r.itemID==id and type(r.name)=='string' and r.name:match('^Item %d') then
      self.bagNameRetry=self.bagNameRetry or {}
      if not self.bagNameRetry[id] then self.bagNameRetry[id]=true;self.bagsDirty=true end
      return
    end
  end
end)
M:RegisterHandler('AUCTION_CANCELED',function(self,_,id)
  self:AddLedger('cancelled',{auctionID=id,status='observed',evidence='Observed AUCTION_CANCELED; lost deposit unknown'})
end)
M:RegisterHandler('AUCTION_HOUSE_AUCTION_CREATED',function(self,_,id)
  self:AddLedger('posted',{auctionID=id,status='observed',evidence='Observed creation; price/deposit captured only if supplied by client'})
end)

-- Name for one of your auctions: the AH's own name for its exact key (with the
-- suffix). A scanned name is only used when it isn't another suffix's.
function M:OwnedAuctionName(key,m,info)
 local id=info and info.itemKey and info.itemKey.itemID
 local full=self.KeyFullName and self:KeyFullName(key)
 if full then return full end
 local base=self:ItemName(id) or (GetItemInfo and GetItemInfo(id))
 local scanned=m and m.name
 if scanned and not m.mixedVariants and (not base or self:NameScore(scanned,base)>0) then return scanned end
 return base or scanned or ('Item '..tostring(id))
end

-- AH item key of a bag item, only when it carries a suffix the link lacks.
function M:BagAHKey(bag,slot,itemID)
 local A=C_AuctionHouse
 if not (A and A.GetItemKeyFromItem and ItemLocation and ItemLocation.CreateFromBagAndSlot) then return nil end
 local ok,k=pcall(function() return A.GetItemKeyFromItem(ItemLocation:CreateFromBagAndSlot(bag,slot)) end)
 if not ok or type(k)~='table' or k.itemID~=itemID or (tonumber(k.itemSuffix) or 0)==0 then return nil end
 return self:Key(k.itemID,k.itemSuffix,k.itemLevel or 0,k.battlePetSpeciesID or 0)
end
