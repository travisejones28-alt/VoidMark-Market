local _,M=...
-- Flipping helpers for the Shopping tab (1.14.0).
--  * Search terms in shopping lists ("of the Monkey"): searching a list also
--    runs each term as a live Auction House name search and merges the results.
--  * "Vs Avg" on every result: the lowest price against that exact item's own
--    30-day history. Random-suffix items are their own market (Boots of the
--    Monkey and Boots of the Bear never share a price).
-- Terms are kept on this character only; item entries still sync as before.
local MAX_TERMS,MIN_SAMPLES=30,2
-- Term format (like Auctionator's extended search, in plain words):
--   [armor] [slot]: [text] [max 75s] [lvl 15+ | lvl 15-30]
--   "leather: agility max 50s", "cloth: intellect lvl 15+", "mail head: max 75s"
-- Armor/slot are checked on the item (Armor class 4). With no text, armor is
-- required and the AH is asked by category instead of by name.
local ARMOR={cloth=1,leather=2,mail=3,plate=4}
local SLOT={head={'INVTYPE_HEAD'},shoulder={'INVTYPE_SHOULDER'},shoulders={'INVTYPE_SHOULDER'},
 chest={'INVTYPE_CHEST','INVTYPE_ROBE'},waist={'INVTYPE_WAIST'},belt={'INVTYPE_WAIST'},legs={'INVTYPE_LEGS'},
 feet={'INVTYPE_FEET'},boots={'INVTYPE_FEET'},wrist={'INVTYPE_WRIST'},bracers={'INVTYPE_WRIST'},
 hands={'INVTYPE_HAND'},gloves={'INVTYPE_HAND'},back={'INVTYPE_CLOAK'},cloak={'INVTYPE_CLOAK'},
 ring={'INVTYPE_FINGER'},rings={'INVTYPE_FINGER'},finger={'INVTYPE_FINGER'},
 neck={'INVTYPE_NECK'},necklace={'INVTYPE_NECK'},amulet={'INVTYPE_NECK'},trinket={'INVTYPE_TRINKET'}}
-- Jewelry is Armor > Miscellaneous on the AH.
local JEWELRY={INVTYPE_FINGER=true,INVTYPE_NECK=true,INVTYPE_TRINKET=true}
local INVTYPE_ENUM={INVTYPE_HEAD=1,INVTYPE_SHOULDER=3,INVTYPE_CHEST=5,INVTYPE_WAIST=6,INVTYPE_LEGS=7,
 INVTYPE_FEET=8,INVTYPE_WRIST=9,INVTYPE_HAND=10,INVTYPE_CLOAK=16,INVTYPE_ROBE=20,
 INVTYPE_NECK=2,INVTYPE_FINGER=11,INVTYPE_TRINKET=12}
-- Blizzard's own enum when present (what the AH categories use), else the fixed IDs.
local ENUM_NAME={INVTYPE_HEAD='IndexHeadType',INVTYPE_SHOULDER='IndexShoulderType',INVTYPE_CHEST='IndexChestType',
 INVTYPE_WAIST='IndexWaistType',INVTYPE_LEGS='IndexLegsType',INVTYPE_FEET='IndexFeetType',INVTYPE_WRIST='IndexWristType',
 INVTYPE_HAND='IndexHandType',INVTYPE_CLOAK='IndexCloakType',INVTYPE_ROBE='IndexRobeType',
 INVTYPE_NECK='IndexNeckType',INVTYPE_FINGER='IndexFingerType',INVTYPE_TRINKET='IndexTrinketType'}
function M:InventoryTypeFilter(equip)
 local e=Enum and Enum.InventoryType and Enum.InventoryType[ENUM_NAME[equip] or '']
 return tonumber(e) or INVTYPE_ENUM[equip]
end
-- Azmork's list (one list for everything).
-- "green" asks the AH for greens only: far fewer result pages, so the list
-- search finishes much faster (these suffixes are green items).
M.FLIP_STARTER={'green cloth: magic','green leather: agility max 50s','green leather: monkey','green mail: bear','green cloth: sorcerer',
 'green cloth: intellect lvl 15+','green leather: tiger','green leather head: max 75s','green mail: strength','green mail head: max 75s',
 'green cloth: healing max 75s','green cloth: physician max 75s'}
-- 1.15-1.20 starter terms (no quality), replaced by /vmm flipstarter.
M.OLD_FLIP_STARTER_2={'cloth: magic','leather: agility max 50s','leather: monkey','mail: bear','cloth: sorcerer',
 'cloth: intellect lvl 15+','leather: tiger','leather head: max 75s','mail: strength','mail head: max 75s',
 'cloth: healing max 75s','cloth: physician max 75s'}
-- 1.14.0 starter terms, replaced by /vmm flipstarter.
M.OLD_FLIP_STARTER={'leather: of Agility','leather: of the Monkey','leather: of the Tiger',
 'cloth: of Healing','cloth: of Intellect','cloth: of the Sorcerer','cloth: of the Physician','cloth: of Magic',
 'mail: of the Bear','mail: of the Tiger','mail: of Strength'}
-- "75s", "1g", "1g25s", "50c", "75" (silver) -> copper
function M:ParseMoneyText(t)
 t=tostring(t or ''):lower():gsub('%s','')
 if t:match('^%d+$') then return tonumber(t)*100 end
 local total,any=0,false
 for n,u in t:gmatch('(%d+)([gsc])') do any=true;total=total+tonumber(n)*(u=='g' and 10000 or u=='s' and 100 or 1) end
 if not any or t:gsub('%d+[gsc]','')~='' then return nil end
 return total>0 and total or nil
end
-- Returns search text, armor subclass, and the full spec.
-- Quality words in the prefix ("green cloth: magic"), Auctionator's quality numbers.
local QUALITY={grey=0,gray=0,poor=0,white=1,common=1,green=2,uncommon=2,blue=3,rare=3,epic=4,purple=4}
local QUALITY_WORD={[0]='grey',[1]='white',[2]='green',[3]='blue',[4]='epic'}
function M:ParseShopTerm(term)
 term=tostring(term or '')
 local spec={}
 local head,rest=term:match('^%s*([%a ]-)%s*:%s*(.-)%s*$')
 if head then
  local ok=true
  for w in head:lower():gmatch('%a+') do
   if ARMOR[w] and not spec.armor then spec.armor=ARMOR[w]
   elseif SLOT[w] and not spec.slot then spec.slot=SLOT[w]
   elseif QUALITY[w] and not spec.quality then spec.quality=QUALITY[w]
   else ok=false end
  end
  if ok and (spec.armor or spec.slot or spec.quality) then term=rest else spec={} end
 end
 term=' '..term..' '
 term=term:gsub('%s[Mm][Aa][Xx]%s+(%S+)%s',function(v) spec.max=self:ParseMoneyText(v);return ' ' end)
 term=term:gsub('%s[Ll][Vv][Ll]%s+(%d+)%s*%-%s*(%d+)%s',function(a,b) spec.minLevel,spec.maxLevel=tonumber(a),tonumber(b);return ' ' end)
 term=term:gsub('%s[Ll][Vv][Ll]%s+(%d+)%+%s',function(a) spec.minLevel=tonumber(a);return ' ' end)
 term=term:gsub('%s[Ll][Vv][Ll]%s+(%d+)%-%s',function(a) spec.maxLevel=tonumber(a);return ' ' end)
 spec.text=term:match('^%s*(.-)%s*$')
 -- "Lupine Vest of Agility" in quotes = that exact name only.
 local exact=spec.text:match('^"(.*)"$');if exact then spec.text=exact;spec.exact=true end
 if spec.minLevel and spec.maxLevel and spec.minLevel>spec.maxLevel then spec.minLevel,spec.maxLevel=spec.maxLevel,spec.minLevel end
 return spec.text,spec.armor,spec
end
-- A term is usable when it has text, or an armor type to search by category.
function M:ShopTermValid(term)
 local text,armor=self:ParseShopTerm(term)
 return #text>=2 or armor~=nil
end
local function itemMatches(itemID,spec)
 if not spec.armor and not spec.slot then return true end
 local info=(C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
 if not info then return true end
 local _,_,_,equip,_,classID,subID=info(itemID)
 if classID==nil then return true end -- unknown to the client yet: keep it
 if spec.armor and not (classID==4 and subID==spec.armor) then return false end
 if spec.slot then
  local hit=false;for _,e in ipairs(spec.slot) do if equip==e then hit=true end end
  if not hit then return false end
 end
 return true
end
M.ShopItemMatchesTerm=itemMatches
function M:FlipMaxBuy()
 local v=tonumber(self.db.settings.flipMaxBuy)
 return (v and v>=1 and v<=1e10) and math.floor(v) or nil
end
-- Required-level range for Shopping searches (0 = no limit on that end).
function M:ShopLevelRange()
 local lo,hi=tonumber(self.db.settings.shopMinLevel),tonumber(self.db.settings.shopMaxLevel)
 lo=(lo and lo>=1 and lo<=80) and math.floor(lo) or nil
 hi=(hi and hi>=1 and hi<=80) and math.floor(hi) or nil
 if lo and hi and lo>hi then lo,hi=hi,lo end
 return lo,hi
end
function M:SetShopLevelRange(lo,hi)
 if self.persistenceBlocked then return end
 lo,hi=tonumber(lo),tonumber(hi)
 self.db.settings.shopMinLevel=(lo and lo>=1 and lo<=80) and math.floor(lo) or 0
 self.db.settings.shopMaxLevel=(hi and hi>=1 and hi<=80) and math.floor(hi) or 0
 self:RefreshUI()
end
-- The Level box and a term's own "lvl ..." both apply (the stricter of each
-- end wins). A term's range used to replace the box: "lvl 15+" ignored 30-40.
function M:EffectiveLevelRange(spec)
 local lo,hi=self:ShopLevelRange()
 if spec then
  if spec.minLevel and (not lo or spec.minLevel>lo) then lo=spec.minLevel end
  if spec.maxLevel and (not hi or spec.maxLevel<hi) then hi=spec.maxLevel end
 end
 return lo,hi
end
function M:ApplyLevelQuery(q,spec)
 local lo,hi=self:EffectiveLevelRange(spec)
 q.minLevel=lo;q.maxLevel=hi;return q
end
-- The AH query already limits level; this double-checks when the item is
-- cached. Items the client doesn't know yet are kept.
function M:LevelAllowed(itemID,spec)
 local lo,hi=self:EffectiveLevelRange(spec)
 if not lo and not hi then return true end
 if not GetItemInfo then return true end
 local ok,_,_,_,_,req=pcall(GetItemInfo,itemID)
 req=ok and tonumber(req) or nil
 if not req then return true end
 return not (lo and req<lo) and not (hi and req>hi)
end
-- Saved market for a live result. Live searches can label gear with its item
-- level while full scans don't (or the reverse), so fall back to the same item
-- and suffix under any level.
function M:MarketForKey(key)
 if key==nil then return nil end
 local m=self.db.market[key];if type(m)=='table' then return m end
 local _,id,suffix=self:ParseKey(key);if not id then return nil end
 suffix=tonumber(suffix) or 0
 local best
 for _,k in ipairs(self.itemIndex and self.itemIndex[id] or {}) do
  local mm=self.db.market[k]
  if type(mm)=='table' and (tonumber(mm.itemSuffix) or 0)==suffix and (not best or (mm.lastSeen or 0)>(best.lastSeen or 0)) then best=mm end
 end
 return best
end
-- Show the exact variant (random suffix) on GameTooltip: auction link first,
-- then the item key, then the base item. Returns how it was shown.
function M:SetVariantTooltip(tip,key,itemID,link)
 if type(link)=='string' and link~='' and tip.SetHyperlink then tip:SetHyperlink(link);return 'link' end
 local m=self:MarketForKey(key)
 if m and type(m.itemLink)=='string' and m.itemLink~='' and tip.SetHyperlink then tip:SetHyperlink(m.itemLink);return 'link' end
 local _,id,suffix,level=self:ParseKey(key)
 id=id or tonumber(itemID)
 if not id then return nil end
 -- Fixed-stat suffixes (positive IDs) render exactly from a built link.
 if (tonumber(suffix) or 0)>0 and tip.SetHyperlink then tip:SetHyperlink(('item:%d:0:0:0:0:0:%d'):format(id,suffix));return 'built' end
 if tip.SetItemKey and (tonumber(suffix) or 0)~=0 then
  local ok=pcall(tip.SetItemKey,tip,id,tonumber(level) or 0,tonumber(suffix) or 0)
  if ok then return 'key' end
 end
 if tip.SetItemByID then tip:SetItemByID(id) end
 return 'base'
end

-- Required level of an item (nil until the game has loaded it).
-- request=true asks the game to load an uncached item (once per session) and
-- redraws when it arrives; only visible rows ask, so a long list never floods it.
local levelAsked={}
function M:ItemRequiredLevel(itemID,request)
 itemID=tonumber(itemID);if not itemID then return nil end
 local info=(C_Item and C_Item.GetItemInfo) or GetItemInfo
 local req
 if info then local ok,_,_,_,_,r=pcall(info,itemID);req=ok and tonumber(r) or nil end
 if not req and request and not levelAsked[itemID] then
  levelAsked[itemID]=true
  local load=C_Item and C_Item.RequestLoadItemDataByID
  if load then pcall(load,itemID) end
  self.levelWaiting=self.levelWaiting or {};self.levelWaiting[itemID]=true
 end
 return req
end
function M:RowLevel(row,request)
 if type(row)~='table' then return nil end
 if row.reqLevel==nil then row.reqLevel=self:ItemRequiredLevel(row.itemID,request) end
 return row.reqLevel
end
M:RegisterHandler('GET_ITEM_INFO_RECEIVED',function(self,_,id)
 id=tonumber(id)
 if id and self.levelWaiting and self.levelWaiting[id] then self.levelWaiting[id]=nil;self:RefreshUI() end
end)
function M:LevelRangeText()
 local lo,hi=self:ShopLevelRange()
 if lo and hi then return 'level '..lo..'-'..hi elseif lo then return 'level '..lo..'+' elseif hi then return 'level '..hi..' or lower' end
end

-- Adds the starter terms to the main Shopping list (one list for everything).
function M:AddFlipStarter()
 local added=0
 local book=self:ShopTermBook('Shopping')
 if book then for _,list in ipairs({self.OLD_FLIP_STARTER,self.OLD_FLIP_STARTER_2}) do for _,old in ipairs(list) do for i=#book,1,-1 do if book[i]==old then table.remove(book,i) end end end end end
 for _,t in ipairs(self.FLIP_STARTER) do if self:AddShopTerm('Shopping',t) then added=added+1 end end
 return added
end

-- Search terms -------------------------------------------------------------
local function trim(s) return (tostring(s or ''):gsub('[%c|]',' '):match('^%s*(.-)%s*$')) end
function M:ShopTermBook(list,create)
 if type(list)~='string' or list=='' then return nil end
 if type(self.db.shopTerms)~='table' then if not create then return nil end;self.db.shopTerms={} end
 local t=self.db.shopTerms[list]
 if type(t)~='table' then if not create then return nil end;t={};self.db.shopTerms[list]=t end
 return t
end
function M:ShopTerms(list)
 local out={}
 for _,term in ipairs(self:ShopTermBook(list) or {}) do if type(term)=='string' and term~='' then out[#out+1]=term end end
 return out
end
function M:AddShopTerm(list,text)
 if self.persistenceBlocked then return false,'Database read-only' end
 text=trim(text)
 if #text<2 or #text>60 then return false,'Search terms must be 2-60 characters' end
 if not self:ShopTermValid(text) then return false,'Add search text, or an armor type like "leather head: max 75s"' end
 local book=self:ShopTermBook(list,true);if not book then return false,'Open a shopping list first' end
 for _,t in ipairs(book) do if type(t)=='string' and t:lower()==text:lower() then return false,'"'..text..'" is already in '..list end end
 if #book>=MAX_TERMS then return false,MAX_TERMS..' search terms per list maximum' end
 book[#book+1]=text;self:RefreshUI();return true
end
function M:RemoveShopTerm(list,text)
 local book=self:ShopTermBook(list);if not book then return false end
 for i=#book,1,-1 do if book[i]==text then table.remove(book,i) end end
 if #book==0 and self.db.shopTerms then self.db.shopTerms[list]=nil end
 if self.termRows then
  for i=#self.termRows,1,-1 do if self.termRows[i].term==text then table.remove(self.termRows,i) end end
 end
 self:RefreshUI();return true
end

-- Auctionator shopping list export: "List Name^term^term" (one list per line).
-- Extended terms are "text;category;minItemLevel;maxItemLevel;minLevel;maxLevel;
-- minCrafted;maxCrafted;minPrice;maxPrice(gold);quality;tier;expansion;quantity"
-- (Auctionator 345 Source/Search/Advanced.lua). Converted to Market terms.
function M:CopperText(c)
 c=math.floor(tonumber(c) or 0);local g,s,cp=math.floor(c/10000),math.floor(c/100)%100,c%100
 local out=(g>0 and (g..'g') or '')..(s>0 and (s..'s') or '')..(cp>0 and (cp..'c') or '')
 return out~='' and out or '0c'
end
function M:AuctionatorTermToMarket(raw)
 local f={};for p in (tostring(raw or '')..';'):gmatch('(.-);') do f[#f+1]=p end
 local text=trim(f[1] or '')
 local prefix={}
 -- 0/blank = any quality (a grey-only filter is never what a flip list means).
 local q=tonumber(f[11]);if q and q>0 and QUALITY_WORD[q] then prefix[#prefix+1]=QUALITY_WORD[q] end
 local cat={};for c in (tostring(f[2] or '')..'/'):gmatch('(.-)/') do if c~='' then cat[#cat+1]=c:lower() end end
 if cat[1]=='armor' then
  if cat[2] and ARMOR[cat[2]] then prefix[#prefix+1]=cat[2] end
  if cat[3] then local w=cat[3]:match('^(%a+)');if w and SLOT[w] then prefix[#prefix+1]=w end end
 end
 local opts={}
 local lo,hi=tonumber(f[5]),tonumber(f[6]);lo=(lo and lo>0) and lo or nil;hi=(hi and hi>0) and hi or nil
 if lo and hi then opts[#opts+1]='lvl '..lo..'-'..hi elseif lo then opts[#opts+1]='lvl '..lo..'+' elseif hi then opts[#opts+1]='lvl '..hi..'-' end
 local maxGold=tonumber(f[10]);if maxGold and maxGold>0 then opts[#opts+1]='max '..self:CopperText(maxGold*10000) end
 local body=text..(#opts>0 and ((text~='' and ' ' or '')..table.concat(opts,' ')) or '')
 local hasArmor=false;for _,w in ipairs(prefix) do if ARMOR[w] then hasArmor=true end end
 if #prefix>0 and (body~='' or hasArmor) then return table.concat(prefix,' ')..': '..body end
 return body
end
function M:ImportAuctionatorLists(raw)
 if self.persistenceBlocked then return false,'Database read-only' end
 if type(raw)~='string' or #raw>35000 then return false,'Invalid import' end
 local lists,terms=0,0
 for line in (raw:gsub('\r\n','\n')..'\n'):gmatch('(.-)\n') do
  if line:find('^',1,true) then
   local parts={};for p in (line..'^'):gmatch('(.-)%^') do parts[#parts+1]=p end
   local name=trim(parts[1]):sub(1,24)
   -- Same list regardless of case ("shopping" -> your main "Shopping" list).
   if name:lower()=='shopping' then name='Shopping' end
   for existing in pairs(self.db.shoppingLists or {}) do if type(existing)=='string' and existing:lower()==name:lower() then name=existing end end
   if name~='' and self:ListBook(name,true) then
    lists=lists+1
    for i=2,#parts do
     local term=parts[i]:find(';',1,true) and self:AuctionatorTermToMarket(parts[i]) or trim(parts[i])
     if self:AddShopTerm(name,term) then terms=terms+1 end
    end
   end
  end
 end
 if lists==0 then return false,'Nothing to import. Paste an Auctionator export like: Flips^of the Monkey^of the Tiger' end
 return true,('Imported %d search term%s into %d list%s'):format(terms,terms==1 and '' or 's',lists,lists==1 and '' or 's')
end

-- Term sweep --------------------------------------------------------------
-- Runs each term through the AH queue one after another; results are merged
-- by item (lowest price wins) into self.termRows, shown with the list.
function M:SearchShopTerms(list,onlyTerm)
 self.lastUserAHAction=GetTime and GetTime() or 0
 local terms=self:ShopTerms(list)
 if onlyTerm then terms={onlyTerm} end
 if #terms==0 or not self.ahOpen or not self:CanUseAuctionHouse() then return false end
 if not (C_AuctionHouse and C_AuctionHouse.GetBrowseResults) then self:Print('Live browse unavailable');return false end
 local run={list=list,total=0,done=0,found=0,rows={},byKey={}}
 self.termSearch=run;self.termRows={}
 for _,term in ipairs(terms) do
  local text,armor,spec=self:ParseShopTerm(term)
  local classFilters,filters={},{}
  local qf=spec.quality and Enum and Enum.AuctionHouseFilter and ({[0]='PoorQuality','CommonQuality','UncommonQuality','RareQuality','EpicQuality'})[spec.quality]
  if qf and Enum.AuctionHouseFilter[qf] then filters[1]=Enum.AuctionHouseFilter[qf] end
  if text=='' and armor then
   -- Category search: Armor > subclass (> slot when it is one inventory type).
   local inv=spec.slot and #spec.slot==1 and self:InventoryTypeFilter(spec.slot[1])
   classFilters[1]={classID=4,subClassID=armor,inventoryType=inv or nil}
  elseif not armor and spec.slot and #spec.slot==1 and JEWELRY[spec.slot[1]] then
   -- "ring: sorcerer": ask for Armor > Miscellaneous (rings, necks, trinkets);
   -- only the asked-for slot is kept here. The slot itself isn't sent: if
   -- Forever ignored it the search came back empty.
   classFilters[1]={classID=4,subClassID=0}
  end
  local id='browse-term:'..term:lower();local pages=0
  local fail
  local function done()
    if self.termSearch~=run then return end
    pages=pages+1
    local result=C_AuctionHouse.GetBrowseResults() or {}
    for i=1,math.min(5000,#result) do
     local b=result[i];local k=b.itemKey
     local key=k and self:Key(k.itemID,k.itemSuffix,k.itemLevel,k.battlePetSpeciesID)
     if key and self:Finite(b.minPrice,1,1e12) then
      self:RecordLiveFloor(key,b.minPrice,b.totalQuantity)
      local old=run.byKey[key]
      local max=spec.max or self:FlipMaxBuy()
      local info=(spec.quality or spec.exact) and C_AuctionHouse.GetItemKeyInfo and C_AuctionHouse.GetItemKeyInfo(k) or nil
      local keep=not (info and spec.quality and info.quality~=nil and info.quality~=spec.quality)
       and not (info and spec.exact and type(info.itemName)=='string' and info.itemName:lower()~=text:lower())
      if keep and (not old or b.minPrice<old.floor) and itemMatches(k.itemID,spec) and not (max and b.minPrice>max) and self:LevelAllowed(k.itemID,spec) then
       local m=self.db.market[key];info=info or (C_AuctionHouse.GetItemKeyInfo and C_AuctionHouse.GetItemKeyInfo(k))
       local row={marketKey=key,itemID=k.itemID,name=self:KeyInfoName(info) or (m and m.name) or self:ItemName(k.itemID) or ('Item '..k.itemID),
        floor=b.minPrice,quantity=tonumber(b.totalQuantity),fair=m and m.fairValue or 0,
        confidence=m and m.confidence or 'Unknown',status='LIVE BROWSE',term=term}
       if not old then run.rows[#run.rows+1]=row;run.found=run.found+1 else for j,r in ipairs(run.rows) do if r==old then run.rows[j]=row end end end
       run.byKey[key]=row
      end
     end
    end
    self.termRows=run.rows
    -- More pages of this term come before the next term.
    if self:BrowseNeedsMore(pages) and self:QueueBrowseMore(id,done,fail) then self:RefreshUI();return end
    run.done=run.done+1
    if run.done>=run.total then run.finished=true
     self:Print(('Search terms: %d item%s found in %s'):format(run.found,run.found==1 and '' or 's',list)) end
    self:RefreshUI()
  end
  fail=function()
    if self.termSearch~=run then return end
    run.done=run.done+1;run.failed=(run.failed or 0)+1
    if run.done>=run.total then run.finished=true end
    self:RefreshUI()
  end
  local queued=self:QueueRequest({id=id,kind='browse',priority=40,
   query=self:ApplyLevelQuery({searchString=text,sorts={},filters=filters,itemClassFilters=classFilters},spec),
   done=done,fail=fail})
  if queued then run.total=run.total+1 end
 end
 if run.total==0 then self.termSearch=nil;return false end
 self:RefreshUI();return true
end
function M:TermSearchRunning()
 local r=self.termSearch;return r~=nil and not r.finished
end
function M:StopTermSearch()
 self.termSearch=nil
 local q=self.queue;if not q then return end
 for i=#q.waiting,1,-1 do
  local r=q.waiting[i]
  if type(r.id)=='string' and r.id:find('^browse%-term:') then table.remove(q.waiting,i);q.dedupe[r.id]=nil end
 end
end
function M:TermSearchStatus()
 local r=self.termSearch
 if r and not r.finished then return 'Searching terms in '..r.list..': '..r.done..' / '..r.total..' | Keep the AH open' end
end

-- Deal check --------------------------------------------------------------
function M:DealPercent()
 local p=tonumber(self.db.settings.dealPercent)
 return (p and p>=10 and p<=100) and math.floor(p) or 60
end
-- Reference price for one exact market: 30-day median of full scans, else the
-- model's fair value once it is trusted. Nil when there is no real history.
-- Daily lows (like Auctionator's price history): the lowest price seen each
-- day from any live search, kept 30 days per exact variant and per base item
-- (all suffixes together, Auctionator's own key on Forever).
local DAY=86400
local function lowBook(self,name)
 if type(self.db[name])~='table' then self.db[name]={} end
 return self.db[name]
end
local function putLow(book,k,day,floor)
 local t=book[k];if type(t)~='table' then t={};book[k]=t end
 if not t[day] or floor<t[day] then t[day]=floor end
 for d in pairs(t) do if type(d)~='number' or d<day-30 then t[d]=nil end end
end
-- Size cap: past the limit, the items not seen for the longest are dropped.
M.DAILY_LOW_CAP,M.DAILY_LOW_BASE_CAP=6000,3000
function M:PruneDailyLows(name,cap)
 local book=self.db[name];if type(book)~='table' then return 0 end
 local list={}
 for k,t in pairs(book) do
  local newest=-1;if type(t)=='table' then for d in pairs(t) do if type(d)=='number' and d>newest then newest=d end end end
  list[#list+1]={k=k,d=newest}
 end
 if #list<=cap then return 0 end
 table.sort(list,function(a,b) return a.d<b.d end)
 local drop=#list-math.floor(cap*0.85)
 for i=1,drop do book[list[i].k]=nil end
 return drop
end
function M:RecordDailyLow(key,floor)
 if self.persistenceBlocked or key==nil or not self:Finite(floor,1,1e12) then return end
 local _,id=self:ParseKey(key);local day=math.floor(time()/DAY);floor=math.floor(floor)
 putLow(lowBook(self,'dailyLows'),tostring(key),day,floor)
 if id then
  putLow(lowBook(self,'dailyLowsBase'),id,day,floor)
  self.lastLiveKey=self.lastLiveKey or {};self.lastLiveKey[id]=key
 end
 self.dailyLowWrites=(self.dailyLowWrites or 0)+1
 if self.dailyLowWrites%250==0 then
  self:PruneDailyLows('dailyLows',self.DAILY_LOW_CAP);self:PruneDailyLows('dailyLowsBase',self.DAILY_LOW_BASE_CAP)
 end
end
-- /vmm check: how this item is labeled, and what Market has saved for it.
function M:CheckItem(link)
 if type(link)~='string' or not link:find('item:',1,true) then
  local tip=GameTooltip;if tip and tip.GetItem and tip:IsShown() then local _,l=tip:GetItem();link=l end
 end
 if type(link)~='string' or link=='' then self:Print('Hover an item and type /vmm check, or type /vmm check then Shift-click an item.');return false end
 local key=self.LinkIdentity and self:LinkIdentity(link)
 local _,id,suffix=self:ParseKey(key)
 local direct=key~=nil and self.db.market[key]
 local m=self:MarketForKey(key)
 local mk;if m then for k,v in pairs(self.db.market) do if v==m then mk=k;break end end end
 local month=m and self:MarketWindow(m,30)
 local lows=0;for _ in pairs(self.db.dailyLows and self.db.dailyLows[tostring(key)] or {}) do lows=lows+1 end
 local blows=0;for _ in pairs(self.db.dailyLowsBase and self.db.dailyLowsBase[id] or {}) do blows=blows+1 end
 local ref,samples,approx=self:DealReference(key)
 local live=self.lastLiveKey and id and self.lastLiveKey[id]
 local req=self:ItemRequiredLevel(id)
 self:Print('Check: '..link:gsub('|','||'))
 self:Print(('  link key %s (item %s, suffix %s)'):format(tostring(key),tostring(id),tostring(suffix)))
 self:Print('  last live-search key '..tostring(live)..(live~=nil and live~=key and ' |cffff8060(different from the link key)|r' or ''))
 self:Print('  saved prices: '..(direct and 'found under the link key' or m and ('found under '..tostring(mk)..' (matched by item + suffix)') or 'none')
  ..(month and (', '..month.samples..' scan samples in 30 days') or ''))
 self:Print(('  daily lows: %d days this suffix, %d days all suffixes'):format(lows,blows))
 self:Print('  Vs Avg reference: '..(ref and (self:Coins(ref)..' from '..tostring(samples)..' samples'..(approx and ' (all suffixes, ~)' or '')) or 'none yet'))
 self:Print('  required level: '..tostring(req or 'not loaded')..'  |  ledger buys: '..#self:BoughtHistory(link)..', sales: '..#self:SoldHistory(link))
 return true
end
local function median(v)
 if #v==0 then return nil end
 table.sort(v);local n=#v
 return math.floor((n%2==1 and v[(n+1)/2] or (v[n/2]+v[n/2+1])/2)+0.5)
end
local function lowsInto(out,t)
 local cutoff=math.floor(time()/DAY)-30
 if type(t)=='table' then for d,v in pairs(t) do if type(d)=='number' and d>=cutoff and tonumber(v) then out[#out+1]=v end end end
end
-- Reference price: this exact variant's 30-day history (full-scan samples plus
-- daily lows); when that is too thin, the same item across all suffixes,
-- marked approximate. Returns price, samples, approximate.
function M:DealReference(key)
 if key==nil then return nil end
 local m=self:MarketForKey(key)
 local month=m and self:MarketWindow(m,30)
 if month and month.samples>=MIN_SAMPLES then return month.median,month.samples,false end
 local values={}
 lowsInto(values,self.db.dailyLows and self.db.dailyLows[tostring(key)])
 if month then values[#values+1]=month.median end
 if #values>=MIN_SAMPLES then return median(values),#values,false end
 if m and self:Finite(m.fairValue,1,1e12) and self:CanEstimateResale(m) then return math.floor(m.fairValue),month and month.samples or 0,false end
 -- Same item, any suffix.
 local _,id=self:ParseKey(key);if not id then return nil end
 local base={}
 lowsInto(base,self.db.dailyLowsBase and self.db.dailyLowsBase[id])
 for _,k in ipairs(self.itemIndex and self.itemIndex[id] or {}) do
  local w=self.db.market[k] and self:MarketWindow(self.db.market[k],30)
  if w then base[#base+1]=w.median end
 end
 if #base>=MIN_SAMPLES then return median(base),#base,true end
end
-- Percent of the reference price the lowest listing costs (45 = 55% under).
function M:DealRatio(row)
 if type(row)~='table' or not self:Finite(row.floor,1,1e12) then return nil end
 local ref,_,approx=self:DealReference(row.marketKey)
 if not ref then return nil end
 return math.floor(row.floor/ref*100+0.5),ref,approx
end
function M:DealText(row)
 local pct,_,approx=self:DealRatio(row)
 if not pct then return '|cff8f8f8f--|r' end
 -- "~" = compared with the item across all suffixes (no history for this one yet).
 local t=(approx and '~' or '')..pct..'%'
 if pct<=self:DealPercent() then return '|cff40ff40'..t..'|r' end
 if pct<100 then return '|cffffffff'..t..'|r' end
 return '|cffff8060'..t..'|r'
end

-- Hidden lists: built in, never shown until unlocked with their command
-- (not listed in /vmm help). Unlocking adds them as a normal shopping list.
M.SECRET_LISTS={
 -- Your first list (Azmork's gear suffixes), greens only so it searches fast.
 gear={name='Gear flips',order=1,terms=M.FLIP_STARTER},
 rings={order=2,name='Rings 40-49',terms={
  'ring: sorcerer max 1g50s lvl 40-49','ring: bandit max 1g50s lvl 40-49',
  'ring: beast max 1g50s lvl 40-49','ring: physician max 1g50s lvl 40-49'}},
}
function M:UnlockSecretList(id,off)
 local s=self.SECRET_LISTS[tostring(id or ''):lower()]
 if not s or self.persistenceBlocked then return false end
 if off then
  if self.db.shoppingLists[s.name] then self:DeleteShoppingList(s.name) end
  self:Print(s.name..' hidden.');return true
 end
 if not self:ListBook(s.name,true) then self:Print('Too many shopping lists to add '..s.name);return false end
 for _,term in ipairs(s.terms) do self:AddShopTerm(s.name,term) end
 self.shopExpanded=s.name
 self:Print(s.name..' unlocked: it is in Shopping Lists. Clear the Level box before searching it.')
 self:RefreshUI();return true
end

-- /vmm void: a small dropdown at your cursor with every shopping list (click
-- = open it on Shopping and search it) and the hidden lists to unlock or hide.
-- Your lists, the one being searched ticked; click another to switch to it and
-- search it.
function M:VoidMenuEntries()
 local out={{header='SEARCH WHICH LIST?'}}
 local active=self.activeList or (self.db and self.db.activeList) or 'Shopping'
 local function entry(name)
  local n=#(self.ShopTerms and self:ShopTerms(name) or {})
  local on=self.shoppingListMode and active==name
  out[#out+1]={name=name,active=on,
   text=(on and '|cff40ff40> |r' or '   ')..name..(n>0 and ('  |cff8f8f8f('..n..' terms)|r') or ''),
   fn=function() self:VoidMenuOpenList(name) end}
 end
 local ids={};for id in pairs(self.SECRET_LISTS) do ids[#ids+1]=id end
 table.sort(ids,function(a,b) return (self.SECRET_LISTS[a].order or 9)<(self.SECRET_LISTS[b].order or 9) end)
 local secret={}
 for _,id in ipairs(ids) do local s=self.SECRET_LISTS[id];secret[s.name]=true;if self.db.shoppingLists[s.name] then entry(s.name) end end
 local names={}
 for name in pairs(self.db.shoppingLists or {}) do if name~='Shopping' and not secret[name] then names[#names+1]=name end end
 table.sort(names);table.insert(names,1,'Shopping')
 for _,name in ipairs(names) do entry(name) end
 local hidden={}
 for _,id in ipairs(ids) do local s=self.SECRET_LISTS[id];if not self.db.shoppingLists[s.name] then hidden[#hidden+1]=id end end
 if #hidden>0 then
  out[#out+1]={header='HIDDEN LISTS'}
  for _,id in ipairs(hidden) do local s=self.SECRET_LISTS[id]
   out[#out+1]={text='|cffc8a0ffUnlock|r '..s.name,fn=function() self:UnlockSecretList(id);self:VoidMenuOpenList(s.name) end} end
 end
 return out
end
function M:VoidMenuOpenList(name)
 if self.SetView and self.view~='shopping' then pcall(self.SetView,self,'shopping') end
 -- These lists carry their own level ranges; a leftover Level box (e.g. 30-40
 -- with rings 40-49 = level 40 only) would hide almost everything.
 local lo,hi=self:ShopLevelRange()
 if lo or hi then self:SetShopLevelRange(nil,nil);self:Print('Level box cleared - '..name..' uses its own levels.') end
 self:OpenShoppingList(name)
 if not self.ahOpen then self:Print(name..' selected - open the Auction House to search it.') end
end
function M:ShowVoidMenu(anchor)
 local f=self.voidMenu
 if not f then
  f=CreateFrame('Frame','VoidMarkMarketVoidMenu',UIParent,'BackdropTemplate');self.voidMenu=f
  f:SetFrameStrata('FULLSCREEN_DIALOG');f:SetClampedToScreen(true);f:EnableMouse(true);f:SetWidth(230)
  if f.SetBackdrop then
   f:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=14,insets={left=3,right=3,top=3,bottom=3}})
   f:SetBackdropColor(0.035,0.026,0.065,0.97);f:SetBackdropBorderColor(0.48,0.25,0.75,1)
  end
  if UISpecialFrames then table.insert(UISpecialFrames,'VoidMarkMarketVoidMenu') end
  f.items={}
 end
 local entries=self:VoidMenuEntries();local y=-8
 for i,e in ipairs(entries) do
  local b=f.items[i]
  if not b then
   b=CreateFrame('Button',nil,f);b:SetSize(214,18);f.items[i]=b
   b.text=b:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall');b.text:SetPoint('LEFT',6,0);b.text:SetJustifyH('LEFT');b.text:SetWidth(206)
   local hl=b:CreateTexture(nil,'HIGHLIGHT');hl:SetAllPoints();hl:SetColorTexture(0.55,0.3,0.85,0.35);b.hl=hl
  end
  b:ClearAllPoints();b:SetPoint('TOPLEFT',8,y);b:Show()
  if e.header then
   b.text:SetFontObject('GameFontNormalSmall');b.text:SetText(e.header);b:SetScript('OnClick',nil);b:EnableMouse(false)
   if i>1 then y=y-4 end
  else
   b.text:SetFontObject('GameFontHighlightSmall');b.text:SetText(e.text);b:EnableMouse(true)
   b:SetScript('OnClick',function() f:Hide();e.fn() end)
  end
  y=y-18
 end
 for i=#entries+1,#f.items do f.items[i]:Hide() end
 f:SetHeight(-y+8)
 f:ClearAllPoints()
 if anchor and anchor.GetObjectType then f:SetPoint('TOPLEFT',anchor,'BOTTOMLEFT',0,-2)
 else
  local x,cy=0,0
  if GetCursorPosition then x,cy=GetCursorPosition() end
  local s=(UIParent.GetEffectiveScale and UIParent:GetEffectiveScale()) or 1
  f:SetPoint('TOPLEFT',UIParent,'BOTTOMLEFT',x/s,cy/s)
 end
 f:Show()
end

-- The Shopping tab's list button: locked until the owner's password is entered
-- once on this account. Only a scrambled check value is stored here, never the
-- password itself.
local VOID_CHECK=1663215085
function M:VoidPasswordHash(s)
 s='VoidMark:'..tostring(s or ''):lower();local h=7919
 for i=1,#s do h=(h*131+s:byte(i)+i)%2147483647 end
 for _=1,3 do for i=1,#s do h=(h*257+s:byte(i))%2147483647 end end
 return h
end
function M:VoidUnlocked() return self.db and self.db.settings and self.db.settings.voidUnlocked==true end
function M:TryVoidPassword(text)
 if self:VoidPasswordHash(tostring(text or ''):match('^%s*(.-)%s*$'))==VOID_CHECK then
  if not self.persistenceBlocked then self.db.settings.voidUnlocked=true end
  return true
 end
 return false
end
function M:VoidListButtonClick(anchor)
 if self:VoidUnlocked() then return self:ShowVoidMenu(anchor) end
 self:AskShopText('Password:','',function(text)
  if self:TryVoidPassword(text) then
   for id in pairs(self.SECRET_LISTS) do self:UnlockSecretList(id) end
   self:ShowVoidMenu(anchor)
  else self:Print('Wrong password.') end
 end)
end
