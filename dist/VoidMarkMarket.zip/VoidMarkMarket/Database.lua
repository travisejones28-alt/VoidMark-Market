local _,M=...
M.defaults={debug=false,maxTransaction=100000,maxItemSpend=500000,maxQuantity=20,
 maxExposure=2000000,minProfit=100,minROI=0.20,minConfidence=42,minLiquidity=15,
 riskTolerance=0.35,ahCut=0.05,depositReserve=100,maxDataAge=7200,historyDays=90,filter='',sort='score',minGoldReserve=0,sellStrategy='competitive',sellMinMargin=0,sellUndercut=1,postDuration=3,dealPercent=60,flipMaxBuy=0,shopMinLevel=0,shopMaxLevel=0}
function M:InitializeDatabase()
  if type(VoidMarkMarketDB)~='table' then VoidMarkMarketDB={} end
  local root=VoidMarkMarketDB
  if (tonumber(root.schemaVersion) or 0)>1 then
    self.persistenceBlocked=true; root={} -- analyze only in memory; leave newer saved schema untouched
    self:Print('Saved data was created by a newer addon. This session is read-only; update before trading.')
  end
  self.root=root
  self.loadedSavedMarker=type(root.persistenceMarker)=='table'
  root.persistenceMarker=root.persistenceMarker or {createdAt=time(),version=self.version}
  root.settings=type(root.settings)=='table' and root.settings or {}
  for k,v in pairs(self.defaults) do
    if type(root.settings[k])~=type(v) then root.settings[k]=v end
    if type(v)=='number' and (root.settings[k]~=root.settings[k] or root.settings[k]<0 or root.settings[k]>1e12) then root.settings[k]=v end
  end
  root.settings.safeMode=nil -- retire only the obsolete switch
  root.settings.itemPostBid=nil -- 1.9.10 experiment: copper, not the bid, was the cause
  root.settings.ahCut=math.min(0.30,root.settings.ahCut)
  root.settings.riskTolerance=math.min(2,root.settings.riskTolerance)
  root.economies=type(root.economies)=='table' and root.economies or {}
  local realm=GetNormalizedRealmName and GetNormalizedRealmName() or GetRealmName()
  local faction=UnitFactionGroup('player') or 'Unknown'
  self.economyID=tostring(realm)..'|'..faction
  self.characterID=(UnitName('player') or 'Unknown')..'|'..tostring(realm)
  local db=root.economies[self.economyID]
  if type(db)~='table' then db={}; root.economies[self.economyID]=db end
  self.db=db; db.settings=root.settings
  for _,k in ipairs({'market','scans','queries','ownedQueries','opportunities','ledger','inventory','mailSeen','pending','totals','watchlist','banker','sharedPrices','reviewQueue','sellFloors','postQueue','financialDays','wealthHistory','sellStacks','liveSeen','postHistory','sellFavourites','recentSearches','itemNames'}) do
    if type(db[k])~='table' then db[k]={} end
  end
  db.scanSequence=tonumber(db.scanSequence) or 0; db.ledgerSequence=tonumber(db.ledgerSequence) or 0
  -- Keep the legacy global declared in the TOC. User imports it once as documented.
  -- Adopt existing records by reference, without deleting/rewriting the old root.
  if type(TaliaaTradeBetaDB)=='table' and not root.legacyImported then
    local legacy=TaliaaTradeBetaDB
    if type(legacy.market)=='table' then
      for k,m in pairs(legacy.market) do if type(m)=='table' and not db.market[k] then db.market[k]=m end end
    end
    db.scanSequence=math.max(db.scanSequence,tonumber(legacy.scanSequence) or 0)
    db.lastFreshScanRequestAt=legacy.lastFreshScanRequestAt
    db.latestScan=db.latestScan or legacy.latestScan
    root.legacyImported={at=time(),economy=self.economyID,schema=legacy.schemaVersion}
  end
  if self.PruneLiveSeen then self:PruneLiveSeen() end
  -- 1.20.3: fill the Flip Ledger from buys and sales recorded before it existed.
  if not self.persistenceBlocked and self.BackfillFlips and (tonumber(db.flipBackfill) or 0)<1 then
    local ok,buys,sales=pcall(self.BackfillFlips,self)
    if ok then db.flipBackfill=1;if (buys or 0)+(sales or 0)>0 then self:Print(('Flip Ledger: added %d earlier buys and %d earlier sales from your history.'):format(buys,sales)) end end
  end
  self:InitializeSharing()
  db.currentBuild=self:GetBuildSnapshot()
  root.schemaVersion=1; db.schemaVersion=1
  self.exposureDirty=true
  self:RebuildIndexes()
  -- One background pass at login converts history saved by older versions.
  if not self.persistenceBlocked and db.historyFormat~=2 then
    self:PruneDatabase(function() db.historyFormat=2 end)
  end
  if self.InitializeCrafting then self:InitializeCrafting() end
  -- Times saved while the PC clock was ahead: pull them back (background, every login).
  if not self.persistenceBlocked then self:RepairFutureTimes() end
  -- Pending spend is persistent. Reload/close never changes an uncertain purchase to failed.
  for _,p in pairs(db.pending) do
    if type(p)=='table' then
      if p.status=='pending' then p.status='unknown' end
      -- SavedVariables may serialize aliases as independent copies. Canonicalize
      -- unresolved orders by ID so the visible ledger receives later resolutions.
      for i,e in ipairs(db.ledger) do if type(e)=='table' and e.id==p.id then db.ledger[i]=p; break end end
    end
  end
  self:RebuildOpportunities()
end
function M:RebuildIndexes()
  self.marketIndex={}; self.itemIndex={}; self.nameIndex={}; local cursor=nil
  self:AddJob('index',function(start)
    while true do
      local k,m=next(self.db.market,cursor); cursor=k
      if k==nil then return true end
      if type(m)=='table' and tonumber(m.itemID) and type(m.latest)=='table' and type(m.history or {})=='table' then
        m.history=m.history or {}; self.marketIndex[#self.marketIndex+1]=k
        self.itemIndex[m.itemID]=self.itemIndex[m.itemID] or {}; table.insert(self.itemIndex[m.itemID],k)
        if m.name then if self.nameIndex[m.name]==nil then self.nameIndex[m.name]=k else self.nameIndex[m.name]=false end end
        if type(m.suffixFloors)=="table" then for n in pairs(m.suffixFloors) do if n~=m.name and self.nameIndex[n]==nil then self.nameIndex[n]=k end end end
      end
      if debugprofilestop()-start>=self.budget then return false end
    end
  end,function() self:RebuildOpportunities(); if self.RebuildCrafting then self:RebuildCrafting() end; if self.view=='browse' then self:BuildBrowseRows(self.db.settings.filter) end; self:RefreshUI() end)
end
function M:GetMarket(itemID)
  local keys=self.itemIndex[tonumber(itemID)] or {}; local best
  for _,k in ipairs(keys) do local m=self.db.market[k]; if not best or (m.lastSeen or 0)>(best.lastSeen or 0) then best=m end end
  return best
end
function M:GetMarketVariants(itemID)
  local out={}; for _,k in ipairs(self.itemIndex[tonumber(itemID)] or {}) do out[#out+1]=self.db.market[k] end; return out
end
function M:PruneDatabase(done)
  local cursor=nil; local cutoff=time()-self.db.settings.historyDays*86400
  self:AddJob('prune',function(start)
    while true do
      local k,m=next(self.db.market,cursor); cursor=k; if k==nil then return true end
      if type(m)=='table' and type(m.history)=='table' then
        while #m.history>1 and type(m.history[1])=='table' and (tonumber(m.history[1].at) or 0)<cutoff do table.remove(m.history,1) end
        -- Retain the last useful price and aggregate history even for absent markets.
        if (tonumber(m.lastSeen) or 0)<cutoff then m.archived=true end
        -- Older versions stored full snapshots in history; shrink them in place.
        for i,h in ipairs(m.history) do if type(h)=='table' and h.q10~=nil then m.history[i]=self.SlimObservation(h) end end
      end
      if debugprofilestop()-start>=self.budget then return false end
    end
  end,done)
end

-- Saved times in the future (PC clock was ahead for a while) make prices look
-- newer than they are, stop sync pages from being accepted, and confuse
-- "last seen" ages. Walk the saved data in the background and pull any
-- 'at' / 'lastSeen' / '...At' time that's ahead of now back to now.
-- '...Until' fields (guards that are meant to be in the future) are left alone.
local function timeKey(k)
  if type(k)~='string' then return false end
  if k=='at' or k=='lastSeen' or k=='firstSeen' then return true end
  return k:sub(-2)=='At' and not k:find('Until',1,true)
end
function M:RepairFutureTimes(done)
  local now=time();local limit=now+300;local far=now+20*365*86400
  local stack={self.db};local seen={};local fixed=0
  self:AddJob('futuretimes',function(start)
    while true do
      local t=table.remove(stack);if t==nil then return true end
      if not seen[t] then
        seen[t]=true
        for k,v in pairs(t) do
          if type(v)=='table' then stack[#stack+1]=v
          elseif type(v)=='number' and v>limit and v<=far and timeKey(k) then t[k]=now;fixed=fixed+1 end
        end
      end
      if debugprofilestop()-start>=self.budget then return false end
    end
  end,function() self.db.futureTimesFixed=(self.db.futureTimesFixed or 0)+fixed;if done then done(fixed) end end)
end
